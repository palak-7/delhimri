<?php
$con = mysqli_connect("localhost", "u240393233_delhimri", "IuEiB440z^D", "u240393233_delhimri");
?>